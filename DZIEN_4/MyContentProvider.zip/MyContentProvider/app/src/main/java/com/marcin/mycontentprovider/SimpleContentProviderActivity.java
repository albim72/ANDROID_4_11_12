package com.marcin.mycontentprovider;

public class SimpleContentProviderActivity extends MenuActivity {
    public static final String DEBUG_TAG = "SimpleContentProvider";

    @Override
    void prepareMenu() {
        addMenuItem("1. MediaStore", MainActivity.class);
        addMenuItem("2. CallLog", SimpleCallLog.class);
    }
}
